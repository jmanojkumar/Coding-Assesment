using CodingAssessment.MiddleWares;
using Core.Services;
using DomainModel;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Repositories;
using ServiceAgents;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();

builder.Services.AddDbContext<FoodDbContext>(options =>
           options.UseInMemoryDatabase("Food"));


builder.Services.AddScoped<IFoodService, FoodService>();
builder.Services.AddScoped(typeof(IGenericRepository<>), typeof(GenericRepository<>));
builder.Services.AddScoped<IFoodServiceAgent, FoodServiceAgent>();
builder.Services.AddSwaggerGen();

var app = builder.Build();

var foodService = builder.Services.BuildServiceProvider().GetService<IFoodService>();
foodService.AddFoods();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

// global error handler
app.UseMiddleware<ErrorHandlerMiddleware>();

app.MapControllers();

app.Run();
