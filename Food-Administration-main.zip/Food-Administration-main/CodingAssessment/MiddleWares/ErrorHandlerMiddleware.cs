﻿using Refit;
using System.Net;
using System.Text;

namespace CodingAssessment.MiddleWares
{
    public class ErrorHandlerMiddleware
    {
        private readonly RequestDelegate _next;

        public ErrorHandlerMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext context, ILogger<ErrorHandlerMiddleware> _logger)
        {
            try
            {
                await _next(context);
            }
            catch (Exception error)
            {
                await HandleError(context, _logger, error);
            }
        }

        private async Task HandleError(HttpContext context, ILogger<ErrorHandlerMiddleware> _logger, Exception error)
        {
            var response = context.Response;
            response.ContentType = "application/json";
            string errorMessage;

            switch (error)
            {
                case ApplicationException:
                    // custom application error
                    //Eg - Missing Configuration, Data issue etc.
                    response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    errorMessage = "Error in processing your request, please check the log for more details";
                    LogError(error, _logger);
                    break;
                
                case ApiException:
                    {
                        var refitException = (ApiException)error;
                        if (refitException.StatusCode == HttpStatusCode.BadRequest)
                        {
                            response.StatusCode = (int)HttpStatusCode.BadRequest;
                            errorMessage = $"Error in connected service: {refitException.Content}";
                        }
                        else
                        {
                            response.StatusCode = (int)HttpStatusCode.InternalServerError;
                            errorMessage = $"Error in connected service, please check the log for more details";
                        }
                        LogError(error, _logger);
                        break;
                    }
                default:
                    // unhandled error
                    response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    errorMessage = "Error in processing your request, please check the log for more details";
                    LogError(error, _logger);
                    break;
            }
            await response.WriteAsync(errorMessage);
        }

        private void LogError(Exception exception, ILogger<ErrorHandlerMiddleware> _logger)
        {
            var errorMessage = new StringBuilder();
            errorMessage.AppendLine();
            errorMessage.AppendLine("===========================================================================================================================");
            BuildErrorMessage(exception, errorMessage);
            _logger.LogError(errorMessage.ToString());
        }

        private static void BuildErrorMessage(Exception exception, StringBuilder errorMessage)
        {
            //Exception Message
            errorMessage.AppendLine($"Exception Message: {exception.Message}");

            //Stack Trace
            errorMessage.AppendLine($"Stack Trace: {exception.StackTrace}");

            //Inner Exception
            if (exception.InnerException != null)
            {
                errorMessage.AppendLine("Inner Exception:");
                BuildErrorMessage(exception.InnerException, errorMessage);
            }
        }
    }
}
