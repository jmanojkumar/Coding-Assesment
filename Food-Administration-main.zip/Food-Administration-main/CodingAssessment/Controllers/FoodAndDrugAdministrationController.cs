﻿using Core.Services;
using Microsoft.AspNetCore.Mvc;

namespace CodingAssessment.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class FoodAndDrugAdministrationController : ControllerBase
    {
        private readonly IFoodService _foodService;

        public FoodAndDrugAdministrationController(IFoodService foodService)
        {
            _foodService = foodService;
        }

        [Route("GetAll")]
        [HttpPost]
        public IActionResult Getlistoffoodenforcement(FoodSearchRequest searchRequest)
        {
            return Ok(_foodService.GetAllFoods(searchRequest));
        }
    }
}