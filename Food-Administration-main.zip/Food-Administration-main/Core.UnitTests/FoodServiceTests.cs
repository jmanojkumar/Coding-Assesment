﻿using Core.Services;
using DomainModel;
using Moq;
using Repositories;
using ServiceAgents;

namespace Core.UnitTests
{
    [TestClass]
    public class FoodServiceTests
    {
        [TestMethod]
        public void GetAllFoods_ReturnsPagedFoods()
        {
            // Arrange
            var mockRepository = new Mock<IGenericRepository<Food>>();
            var mockAgent = new Mock<IFoodServiceAgent>();

            var foods = new List<Food>
            {
                new Food {ProductDescription = "Product 1", Country = "US" },
                new Food { ProductDescription = "Product 2", Country = "India" },
            };
            mockRepository.Setup(repo => repo.GetAll()).Returns(foods.AsQueryable());

            var foodService = new FoodService(mockAgent.Object, mockRepository.Object);
            var request = new FoodSearchRequest { PageNumber = 1, PageSize = 2 };

            // Act
            var result = foodService.GetAllFoods(request);

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(2, result.Count);
            Assert.AreEqual("US", result[0].Country);
            Assert.AreEqual("India", result[1].Country);
        }

        [TestMethod]
        public void AddFoods_CallsAddRangeOnRepository()
        {
            // Arrange
            var mockRepository = new Mock<IGenericRepository<Food>>();
            var mockAgent = new Mock<IFoodServiceAgent>();
            mockAgent.Setup(x => x.GetFoods()).Returns(new FoodDetails()
            {
                results = new List<Result>()
                {
                    new Result()
                    {
                       country = "United States", city = "Davie", product_description = "Product 1"
                    }
                }
            });
            var foodService = new FoodService(mockAgent.Object, mockRepository.Object);

            // Act
            foodService.AddFoods();

            // Assert
            mockRepository.Verify(repo => repo.AddRange(It.IsAny<List<Food>>()), Times.Once);
        }
    }
}