﻿using DomainModel;
using Repositories;
using ServiceAgents;

namespace Core.Services
{
    public class FoodService : IFoodService
    {
        private readonly IFoodServiceAgent _foodServiceAgent;
        private readonly IGenericRepository<Food> _foodRepository;

        public FoodService(IFoodServiceAgent foodServiceAgent, IGenericRepository<Food> foodRepository)
        {
            _foodServiceAgent = foodServiceAgent;
            _foodRepository = foodRepository;
        }

        public void AddFoods()
        {
            var foods = GetFoodsApi();
            _foodRepository.AddRange(foods);
        }

        public List<Food> GetAllFoods(FoodSearchRequest request)
        {
           var foods =  _foodRepository.GetAll();
           return foods.Skip(request.PageSize * (request.PageNumber - 1)).Take(request.PageSize).ToList();
        }

        private List<Food> GetFoodsApi()
        {
            var data = _foodServiceAgent.GetFoods();
            List<Food> foods = new List<Food>();

            foreach (var food in data.results)
            {
                Food food1 = new Food()
                {
                    Address1 = food.address_1,
                    Address2 = food.address_2,
                    CenterClassificationDate = food.center_classification_date,
                    City = food.city,
                    Classification = food.classification,
                    CodeInfo = food.code_info,
                    Country = food.country,
                    DistributionPattern = food.distribution_pattern,
                    EventId = food.event_id,
                    InitialFirmNotification = food.initial_firm_notification,
                    PostalCode = food.postal_code,
                    ProductDescription = food.product_description,
                    ProductQuantity = food.product_quantity,
                    ProductType = food.product_type,
                    ReasonForRecall = food.reason_for_recall,
                    RecallingFirm = food.recalling_firm,
                    RecallInitiationDate = food.recall_initiation_date,
                    RecallNumber = food.recall_number,
                    ReportDate = food.report_date,
                    State = food.state,
                    Status = food.status,
                    TerminationDate = food.termination_date,
                    VoluntaryMandated = food.voluntary_mandated
                };

                foods.Add(food1);
            }

            return foods;
        }
    }
}
