﻿using DomainModel;

namespace Core.Services
{
    public interface IFoodService
    {
        public List<Food> GetAllFoods(FoodSearchRequest request);

        public void AddFoods();
    }
}
