﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Net.Http.Headers;
using System.Text.Json;

namespace ServiceAgents
{
    public class FoodServiceAgent : IFoodServiceAgent
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<FoodServiceAgent> _logger;

        public FoodServiceAgent(IConfiguration configuration, ILogger<FoodServiceAgent> logger)
        {
            _configuration = configuration;
            _logger = logger;
        }
        public FoodDetails GetFoods()
        {
            using (var client = new HttpClient())
            {
                client.Timeout = new TimeSpan(0, 5, 0);
                var url = _configuration["OpenFDIUrl"];
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync(url).Result;
                string result = response.Content.ReadAsStringAsync().Result;
                try
                {
                    response.EnsureSuccessStatusCode();
                }
                catch (Exception ex)
                {
                    _logger.LogError(result);
                    throw ex;
                }

                return JsonSerializer.Deserialize<FoodDetails>(result);
            }
        }
    }
}
