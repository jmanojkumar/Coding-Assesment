﻿using DomainModel;
using Microsoft.EntityFrameworkCore;

namespace Repositories
{
    public class GenericRepository<TEntity> : IGenericRepository<TEntity> where TEntity : class
    {
        private readonly FoodDbContext _context;
        private readonly DbSet<TEntity> _entities;

        public GenericRepository(FoodDbContext context)
        {
            _context = context;
            _entities = _context.Set<TEntity>();
        }

        public IEnumerable<TEntity> GetAll()
        {
            return _entities.ToList();
        }

        public void AddRange(List<TEntity> entities)
        {
            _entities.AddRange(entities);
            _context.SaveChanges();
        }
    }
}