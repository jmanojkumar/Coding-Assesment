﻿namespace Repositories
{
    public interface IGenericRepository<TEntity>
    {
        
        IEnumerable<TEntity> GetAll();
        void AddRange(List<TEntity> entities);
    }
}