﻿using DomainModel;
using Microsoft.EntityFrameworkCore;
using Moq;
using Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Unittests
{
    [TestClass]
    public class GenericRepositoryTests
    {

      [TestMethod]
        public void GetAll_ReturnsAllEntities()
        {
            // Arrange
            var mockData = new List<Food>
            {
                new Food { RecallNumber = "123", ProductDescription = "Product 1" },
                new Food { RecallNumber = "456", ProductDescription = "Product 2" }
            }.AsQueryable();

            var mockSet = new Mock<DbSet<Food>>();
            mockSet.As<IQueryable<Food>>().Setup(m => m.Provider).Returns(mockData.Provider);
            mockSet.As<IQueryable<Food>>().Setup(m => m.Expression).Returns(mockData.Expression);
            mockSet.As<IQueryable<Food>>().Setup(m => m.ElementType).Returns(mockData.ElementType);
            mockSet.As<IQueryable<Food>>().Setup(m => m.GetEnumerator()).Returns(mockData.GetEnumerator());

            var mockContext = new Mock<FoodDbContext>();
            mockContext.Setup(c => c.Set<Food>()).Returns(mockSet.Object);

            var repository = new GenericRepository<Food>(mockContext.Object);

            // Act
            var entities = repository.GetAll();

            // Assert
            Assert.IsNotNull(entities);
            Assert.AreEqual(2, entities.Count());
            Assert.IsTrue(entities.Any(e => e.RecallNumber == "123" && e.ProductDescription == "Product 1"));
            Assert.IsTrue(entities.Any(e => e.RecallNumber == "456" && e.ProductDescription == "Product 2"));
        }

        [TestMethod]
        public void AddRange_AddsEntitiesToContext()
        {
            // Arrange
            var entitiesToAdd = new List<Food>
            {
                new Food { RecallNumber = "789", ProductDescription = "Product 3" },
                new Food { RecallNumber = "101", ProductDescription = "Product 4" }
            };

            var mockSet = new Mock<DbSet<Food>>();
            var mockContext = new Mock<FoodDbContext>();
            mockContext.Setup(c => c.Set<Food>()).Returns(mockSet.Object);

            var repository = new GenericRepository<Food>(mockContext.Object);

            // Act
            repository.AddRange(entitiesToAdd);

            // Assert
            mockSet.Verify(m => m.AddRange(entitiesToAdd), Times.Once);
            mockContext.Verify(m => m.SaveChanges(), Times.Once);
        }
    }
}